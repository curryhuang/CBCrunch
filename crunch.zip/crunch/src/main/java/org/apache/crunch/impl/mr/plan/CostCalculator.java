package org.apache.crunch.impl.mr.plan;

public interface CostCalculator {
	long getCost();
}
